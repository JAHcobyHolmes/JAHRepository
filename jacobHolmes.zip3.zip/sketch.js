let shapeSize1 = 100;
let shapeSize2 = 100;
let shapeSize3 = 100;



function setup() {
  createCanvas(400, 400);
  frameRate(45);
  colorMode(RGB);
  strokeWeight(7);

}

function draw() {
  background(170);
  fill(200,100,100);
  ellipse(300, 300, shapeSize1, shapeSize3);
  fill(100,255,255);
  ellipse(100, 100, shapeSize2,shapeSize3);
  fill(230,200,255);
  ellipse(200, 230, shapeSize1,shapeSize2);
  
  let lineColor = color(mouseX % 255, mouseY % 255,(mouseX +         mouseY) % 255);
  
  stroke(lineColor);
  
  
  line(pmouseX, pmouseY, mouseX, mouseY);
  function mousePressed()
  {
    point(mouseX, mouseY);
  }
   
}

function keyPressed() {
  // Adjust the sizes of the shapes when a key is pressed
  if (key === '1') {
    shapeSize1 += 10;
  } else if (key === '2') {
    shapeSize2 += 10;
  } else if (key === '3') {
    shapeSize3 += 10;
  }
}