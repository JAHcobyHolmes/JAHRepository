let balls = [];
let gravity = 0.1;
let bounceSound;

function preload() {
  bounceSound = loadSound('recordedAudio/me.mp3');
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);

  for (let i = balls.length - 1; i >= 0; i--) {
    balls[i].update();
    balls[i].display();

    if (
      balls[i].x < 0 ||
      balls[i].x > width ||
      balls[i].y < 0 ||
      balls[i].y > height
    ) {
      balls.splice(i, 1);
    }
  }
}

function mouseClicked() {
  let ball = new Ball(mouseX, mouseY);
  balls.push(ball);
}

class Ball {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.radius = random(10, 30);
    this.speedX = random(-3, 3);
    this.speedY = random(-3, 3);
  }

  update() {
    this.x += this.speedX;
    this.y += this.speedY;

 
    this.speedY += gravity;

    if (this.x + this.radius > width || this.x - this.radius < 0) {
      this.speedX *= -1;
      bounceSound.play();
    }
    if (this.y + this.radius > height || this.y - this.radius < 0) {
      this.speedY *= -1;
      bounceSound.play();
    }
  }

  display() {
    fill(random(255), random(255), random(255));
    ellipse(this.x, this.y, this.radius * 2);
  }
}
