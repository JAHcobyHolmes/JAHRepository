function setup() {
  createCanvas(300, 300);
}

function draw() {
  background(45);
  fill(100);
  noStroke();
  ellipse(200, 20, 5, 5);
  ellipse(143, 54, 5, 5);     
  ellipse(240, 130, 5, 5);      
  ellipse(150, 200, 5, 5);      
  ellipse(100, 274, 5, 5);      
  ellipse(275,20 , 5, 5);
  ellipse(45,175, 10, 23);
  fill(200)
  ellipse(270, 250, 150,150);
  ellipse(100, 100, 80,80);
  stroke(100);
  strokeWeight(4); 
  strokeJoin(MITER);
  line(45,1, 45, 400);
  line(0, 200, 400, 0);
  line(0, 150, 400, 400);
  noFill();
}


  
