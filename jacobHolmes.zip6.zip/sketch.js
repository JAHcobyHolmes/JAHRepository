let halloweenWords = ["pumpkin", "ghost", "witch", "skeleton", "candy", "zombie", "bat", "spider", "haunted", "costume"];
let wordObjects = [];

function setup() {
  createCanvas(400, 400);
  textSize(24);
  textAlign(CENTER, CENTER);
  fill(255, 160, 0);
  
  for (let i = 0; i < halloweenWords.length; i++) {
    let x = random(width);
    let y = random(height);
    let xSpeed = random(1, 3); // Random horizontal speed
    let ySpeed = random(1, 3); // Random vertical speed
    wordObjects.push({ word: halloweenWords[i], x, y, xSpeed, ySpeed });
  }
}

function draw() {
  background(111);
  fill(225);
  
   for (let i = 0; i < wordObjects.length; i++) {

    wordObjects[i].x += wordObjects[i].xSpeed;
    wordObjects[i].y += wordObjects[i].ySpeed;

   
    if (wordObjects[i].x < 0 || wordObjects[i].x > width) {
      wordObjects[i].x = random(width);
    }
    if (wordObjects[i].y < 0 || wordObjects[i].y > height) {
      wordObjects[i].y = random(height);
    }

    
    text(wordObjects[i].word, wordObjects[i].x, wordObjects[i].y);
  }
  for (let i = 0; i < halloweenWords.length; i++) {
    text(halloweenWords[i], width / 2, 40 + i * 30);
  }
  
 print("The length of the 'halloweenWords' array is: " + halloweenWords.length);
  
   print("Words in the 'halloweenWords' array:");
  for (let i = 0; i < halloweenWords.length; i++) {
    print(halloweenWords[i]);
  }
  noLoop();
  
             
  
}