function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);
  background(220);

  
  drawCustomShape(100, 100);
  drawCustomShape(300, 300);
   for (let i = 0; i < 5; i++) {
    let x = random(width);
    let y = random(height);
    let s = random(0.2, 2.0);
    let r = random(TWO_PI); 
    drawCustomShape(x, y, s,r);
    let result = drawCustomShape(x, y, s, r);
    print(result);

  }
}

function draw() {
 
}

function drawCustomShape(x, y, scaleValue, rotationAngle) {
 
  push(); 
  translate(x, y);
  
  scale(scaleValue);    
  rotate(rotationAngle); 

 
  fill(255, 0, 0);
  stroke(0);      
  strokeWeight(2); 

  
  rect(0, 0, 50, 50);       
  ellipse(25, 25, 40, 40); 
  line(0, 0, 50, 50);       

  pop(); 
  
  return `x: ${x}, y: ${y}, scale: ${scaleValue}, rotation: ${rotationAngle}`;
}

